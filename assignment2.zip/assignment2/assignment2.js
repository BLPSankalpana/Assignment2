function hilton(){
    alert("You can make reservation for Hilton Colombo");
}

function hotelSigiriya(){
    alert("You can make reservation for Hotel Sigiriya");
}

function jetwing(){
    alert("You can make reservation for Jetwing Yaala");
}

function cinnamanGrand(){
    alert("You can make reservation for Cinnaman Grand");
}

function Hnegombo(){
    alert("You can make reservation for Heritance Negombo");
}